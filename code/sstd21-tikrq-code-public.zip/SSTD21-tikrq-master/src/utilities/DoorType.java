package utilities;

public class DoorType {
	
	public static int NORMAL = 0;
	
	public static int EXIT = 1;

}
