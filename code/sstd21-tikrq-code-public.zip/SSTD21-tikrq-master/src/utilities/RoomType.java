/**
 * 
 */
package utilities;

/**
 * @author feng zijin
 *
 */
public class RoomType {

	public static int STORE = 0;
	
	public static int HALLWAY = 1;
	
	public static int STAIRCASE = 2;
	
	public static int ELEVATOR = 3;
}
